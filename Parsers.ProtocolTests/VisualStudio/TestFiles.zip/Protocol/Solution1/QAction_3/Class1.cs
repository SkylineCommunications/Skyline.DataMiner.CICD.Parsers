﻿namespace QAction_3
{
    public class Class1
    {
        public string Test()
        {
            return "test";
        }
    }
}
