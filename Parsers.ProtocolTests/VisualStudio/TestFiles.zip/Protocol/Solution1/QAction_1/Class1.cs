﻿namespace QAction_1
{
    public class Class1
    {
    }
}
