﻿using System.Reflection;


[assembly: AssemblyTitle("QAction_1")]
[assembly: AssemblyDescription("")]
