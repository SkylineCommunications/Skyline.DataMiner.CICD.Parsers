﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace QAction_3.Tests
{
    [TestClass()]
    public class Class1Tests
    {
        [TestMethod()]
        public void TestTest()
        {
            Assert.Fail();
        }
    }
}