namespace Skyline.Protocol
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;

    namespace MyExtension
    {
        public class MyClass
        {
        }
    }
}