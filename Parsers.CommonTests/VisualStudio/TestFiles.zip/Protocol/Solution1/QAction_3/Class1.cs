﻿namespace QAction_3
{
    public class Class1
    {
    }
}
