﻿// --- auto-generated code --- do not modify ---
namespace Skyline.DataMiner.Library
{

}