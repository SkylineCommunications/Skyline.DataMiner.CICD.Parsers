﻿using SharedProject;
public class Script
{
    public void Run()
    {

		SharedCode myCode = new SharedCode();
		myCode.TestSharedCall();
    }
}