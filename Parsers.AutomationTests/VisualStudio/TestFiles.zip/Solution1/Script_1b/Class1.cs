﻿namespace Script_1b
{
    public class Class1
    {
    }
}
