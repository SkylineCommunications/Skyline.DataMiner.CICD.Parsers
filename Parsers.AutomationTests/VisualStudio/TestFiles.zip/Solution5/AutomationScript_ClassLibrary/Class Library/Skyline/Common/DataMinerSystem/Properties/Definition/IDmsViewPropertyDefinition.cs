﻿namespace Skyline.DataMiner.Library.Common.Properties
{
    /// <summary>
    /// DataMiner view property definition interface.
    /// </summary>
	public interface IDmsViewPropertyDefinition : IDmsPropertyDefinition
    {
    }
}