﻿namespace Skyline.DataMiner.Library.Common.Properties
{
    /// <summary>
    /// DataMiner service property definition interface.
    /// </summary>
    public interface IDmsServicePropertyDefinition : IDmsPropertyDefinition
    {
    }
}
