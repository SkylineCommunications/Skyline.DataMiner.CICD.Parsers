﻿namespace Skyline.DataMiner.Library.Common.Templates
{
	/// <summary>
	/// DataMiner alarm template interface.
	/// </summary>
	public interface IDmsAlarmTemplate : IDmsTemplate
	{
	}
}