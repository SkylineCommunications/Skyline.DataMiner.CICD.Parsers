﻿namespace Skyline.DataMiner.Library.Common
{
	/// <summary>
	/// interface IPortConnection for which all connections will inherit from.
	/// </summary>
	public interface IPortConnection
	{

	}
}