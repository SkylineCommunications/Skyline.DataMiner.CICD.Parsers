﻿namespace Skyline.DataMiner.Library.Common.Serializing.NoTagSerializing
{
	internal enum XmlSerializerType
	{
		JsonNewtonSoft
	}
}
