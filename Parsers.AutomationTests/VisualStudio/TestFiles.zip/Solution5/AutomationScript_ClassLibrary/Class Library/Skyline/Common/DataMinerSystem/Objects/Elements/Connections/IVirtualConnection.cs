﻿namespace Skyline.DataMiner.Library.Common
{
	/// <summary>
	/// Defines a Virtual Connection
	/// </summary>
	public interface IVirtualConnection : IElementConnection
	{
	}
}