﻿namespace Skyline.DataMiner.Library.Common.Templates
{
	/// <summary>
	/// DataMiner trend template interface.
	/// </summary>
	public interface IDmsTrendTemplate : IDmsTemplate
	{
	}
}