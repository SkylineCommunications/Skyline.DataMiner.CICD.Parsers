﻿namespace Skyline.DataMiner.Library.Common.InterAppCalls.MessageExecution
{
	/// <summary>
	/// Represents an executor for messages.
	/// </summary>
	public interface IBaseMessageExecutor
	{
	}
}