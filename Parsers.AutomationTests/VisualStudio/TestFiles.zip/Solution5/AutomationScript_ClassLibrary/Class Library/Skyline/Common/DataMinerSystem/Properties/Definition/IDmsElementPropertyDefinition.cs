﻿namespace Skyline.DataMiner.Library.Common.Properties
{
    /// <summary>
    /// DataMiner element property definition interface.
    /// </summary>
	public interface IDmsElementPropertyDefinition : IDmsPropertyDefinition
    {
    }
}