﻿namespace Skyline.DataMiner.Library.Common
{
	internal enum GpibApi
	{
		Sicl = 0,
		Visa = 1
	}
}
